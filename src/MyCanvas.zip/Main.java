import javax.swing.*;

public class Main {

    public static void main(String[] args) {
        Menu window= new Menu();
        //MyWindow window = new MyWindow();
        window.setVisible(true);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
